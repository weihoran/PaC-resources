# Kubeops Policy Examples

This directory contains examples in order to apply policies on
[Kubeops](https://github.com/kubeops) curated tools.

Examples

- config-syncer-secret-generation-from-rancher-capi (formerly kubed) - Enable config syncer for Rancher downstream clusters by generating a kubeconfig Secret consisting of downstream cluster contexts where you want to sync your ConfigMap/Secret.
